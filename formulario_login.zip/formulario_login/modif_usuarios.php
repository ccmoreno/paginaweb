<?php
session_start();
error_reporting(0);
$varsesion = $_SESSION['usuario'];
  if($varsesion == null || $varsesion = '')
  {
    echo "Usted no tiene acceso";
    die();
  }

  modificarelusuario($_POST['usuario'],$_POST['password'],$_POST['passadmin'],$_POST['id']);

  function modificarelusuario($usuariomod,$passwordmod,$passadminmod,$id)
  {
    $conexion = mysqli_connect("localhost","root","","usuarios");
    $sentencia="UPDATE users SET usuario='".$usuariomod."', Password='".$passwordmod."',passadmin='".$passadminmod."' WHERE  id='".$id."' ";
    $resultadosent=$conexion->query($sentencia);
  }
?>
  <script>
  alert("Usuario Modificado Correctamente");
  window.location.href='administracion_usuarios.php';

  </script>
