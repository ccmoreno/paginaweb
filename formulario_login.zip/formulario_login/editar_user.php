<?php
session_start();
error_reporting(0);
$varsesion = $_SESSION['usuario'];
  if($varsesion == null || $varsesion = '')
  {
    echo "Usted no tiene acceso";
    die();
  }
  $conexion = mysqli_connect("localhost","root","","usuarios");
 $consultar=consultarusers($_GET['id']);
 function consultarusers($id_user)
 {
   $conexion = mysqli_connect("localhost","root","","usuarios");
   $sentencia="SELECT * FROM users WHERE id='".$id_user."' ";
   $resultadosent=$conexion->query($sentencia);
   $registro_usuarios = $resultadosent->fetch_array(MYSQLI_BOTH);
   return [
     $registro_usuarios['usuario'],
     $registro_usuarios['password'],
     $registro_usuarios['passadmin']
   ];
 }
  ?>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>Editar Usuario</title>
    <link  href="style_editar.css" rel ="stylesheet" type="text/css">
  </head>
  <style>
 body
 {
   background-color: #252850;
 }
</style>
  <body>
  <form action="modif_usuarios.php" method="POST" id="formulario">
    <input type="hidden" name="id" value="<?php echo $_GET['id'] ?>">
    <div>
      <label>Usuario</label>
      <input type="text" id="usuario" name="usuario" value="<?php echo $consultar[0]?>">
    </div>
    <div>
      <label>Password</label>
      <input type="password" id="password" name="password" value="<?php echo $consultar[1]?>">
    </div>
    <label>Passadmin</label>
    <input type="password" id="passadmin" name="passadmin" value="<?php echo $consultar[2]?>">
    <br>
    <button type="submit" class="btn btn-success " name="button" >Guardar Cambios</button>
  </form>
  </body>
</html>
