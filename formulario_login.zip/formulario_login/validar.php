<?php
session_start();
  //declaro variables que reciben los datos ingresados
  $usuario = $_POST['usuario'];
  $password = $_POST['password'];
  $passadmin = $_POST['password'];
  $_SESSION['usuario'] = $usuario ;

//se realiza la conexion con la BD
$conexion = mysqli_connect("localhost","root","","usuarios");
//se valida el usuario que ingrese y la contraseña
$consulta = "SELECT * FROM users WHERE usuario='$usuario' and password='$password'" ;
$consulta2 = "SELECT *  FROM users WHERE usuario='$usuario' and passadmin ='$passadmin'";
//se guardan cariables de resutados
$resultado = mysqli_query($conexion,$consulta);
$resultado2 = mysqli_query($conexion,$consulta2);
//se valida la condicion de los resultados
$filas = mysqli_num_rows($resultado);
if ($filas>0 ) {
  header("location:panel_user.php");
}else{

  $filas2 = mysqli_num_rows($resultado2) ;
    if ($filas2>0) {
      header("location:panel_admin.php");
    }else {
      echo "Error en la autenticación, Usuario no existe ó datos escritos erroneamente ";
    }
}
mysqli_free_result($resultado);
mysqli_free_result($resultado2);
mysqli_close($conexion);

?>
<br>
<h3><a href="cerrar_session.php"style='color: black'>Salir</a></h3>
