<?php
session_start();
error_reporting(0);
$varsesion = $_SESSION['usuario'];
  if($varsesion == null || $varsesion = '')
  {
    echo "Usted no tiene acceso";
    die();
  }

 nuevousuario($_POST['usuario'],$_POST['password'],$_POST['passadmin']);

 function nuevousuario($usuariomod,$passwordmod,$passadminmod)
 {
   $conexion = mysqli_connect("localhost","root","","usuarios");
   $sentencia="INSERT INTO users (usuario,password,passadmin) VALUES ('".$usuariomod."','".$passwordmod."','".$passadminmod."')";
   $resultadosent=$conexion->query($sentencia);

 }
?>
<script>
alert("Usuario Creado Correctamente");
window.location.href='administracion_usuarios.php';
</script>
