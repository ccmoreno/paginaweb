<?php
session_start();
error_reporting(0);
$varsesion = $_SESSION['usuario'];
  if($varsesion == null || $varsesion = '')
  {
    echo "Usted no tiene acceso";
    die();
  }

  eliminarusuario($_GET['id']);

  function eliminarusuario($id)
  {
    $conexion = mysqli_connect("localhost","root","","usuarios");
    $sentencia="DELETE FROM users WHERE id='".$id."' ";
    $resultadosent=$conexion->query($sentencia);
  }
?>
<script>
alert("Usuario Eliminado Correctamente");
window.location.href='administracion_usuarios.php';
</script>
