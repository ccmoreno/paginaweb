<?php

session_start();
error_reporting(0);
$varsesion = $_SESSION['usuario'];
  if($varsesion == null || $varsesion = ''){
    echo "Usted no tiene acceso";
    die();
  }
 ?>
 <!DOCTYPE html>
 <html>
   <head>
     <meta charset="utf-8">
     <title>panel_user</title>
   </head>
   <body>

     <h1>Panel de usuario </h1>
     <h2>Bienvenido usuario</h2>

    <h3><a href="cerrar_session.php"style='color: black'>Cerrar sesión</a></h3>

     <?php
      include("entrega_final.html");
      ?>

   </body>
 </html>
