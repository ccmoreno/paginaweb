function bienvenidos(){
  alert("Bienvenidos a La Pagina Del Arte");
}

function black() {
  titulo.style.color = "black" ;
  titulo.style.fontfamily = "arial";
  titulo.style.fontsize = "40px";

}

function teal() {
  titulomona.style.color = "teal" ;
  titulomona.style.fontfamily = "arial";
  titulomona.style.fontsize = "40px";

  titulocena.style.color = "teal" ;
  titulocena.style.fontfamily = "arial";
  titulocena.style.fontsize = "40px";

  titulogrito.style.color = "teal" ;
  titulogrito.style.fontfamily = "arial";
  titulogrito.style.fontsize = "40px";

  tituloguernica.style.color = "teal" ;
  tituloguernica.style.fontfamily = "arial";
  tituloguernica.style.fontsize = "40px";



}
function white() {

  titulo.style.color = "white" ;
  titulo.style.fontfamily = "arial";
  titulo.style.fontsize = "40px";

  titulomona.style.color = "white" ;
  titulomona.style.fontfamily = "arial";
  titulomona.style.fontsize = "40px";

  titulocena.style.color = "white" ;
  titulocena.style.fontfamily = "arial";
  titulocena.style.fontsize = "40px";

  titulogrito.style.color = "white" ;
  titulogrito.style.fontfamily = "arial";
  titulogrito.style.fontsize = "40px";

  tituloguernica.style.color = "white" ;
  tituloguernica.style.fontfamily = "arial";
  tituloguernica.style.fontsize = "40px";

  titulogrito.style.color = "white" ;
  titulogrito.style.fontfamily = "arial";
  titulogrito.style.fontsize = "40px";



}

function modificar(){
  body.style.background = "green" ;

}


  function reset (){
    body.style.background = "maroon" ;

  }
