<?php
session_start();
error_reporting(0);
$varsesion = $_SESSION['usuario'];
  if($varsesion == null || $varsesion = ''){
    echo "Usted no tiene acceso";
    die();
  }
 ?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
 <title>Las obras mas importantes de arte</title>
 <link  href="miestilo2.css" rel ="stylesheet" type="text/css">
 <script type="text/javascript" src="javascript.js"> </script>

</head>
<body id="body" onload="bienvenidos();">

<header>
  <h2 id="titulo" onmouseover="black();"onmouseout="white();"><center>El Arte</center></h2>
  <nav = class="navegacion" >
 	<ul= class="menu" >
    	<li>
        <a href ="#">Inicio</a>
      </li>
        <li>
          <a href ="#">Nosotros</a>
        </li>
        <li>
          <a href ="administracion_usuarios.php">Administracion de Usuarios</a>
        </li>
    </ul>
  </nav>
</header>
<h1><center>Las 4 pinturas mas famosas </center></h1>

<div id="botones">
  <input onclick="modificar();" type="button" name="modificar" value="modificar">

  <input onclick="reset();" type="button" name="reset" value="reset">

</div>



<div id="estilos" >
    <div id="titulomona" onmouseover="teal();"onmouseout="white();">
      <h1 >LA MONA LISA</h1>
    </div>
    <div >
      <p><strong>La Mona Lisa:</strong> Una de las pinturas más famosas es la mona lisa.</p>
    </div>
    <div >
      <p>También conocida como La Gioconda, es una de las obras más conocidas del artista italiano Leonardo da Vinci y una de las más visitadas del mundo. Es un gran ejemplo de la técnica del claroscuro e hipnotiza por la enigmática sonrisa de la dama retratada. Actualmente se exhibe en el Museo Louvre en París.<p>
    </div>
    <div class="imagen_mona">
      <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/7/73/Leonardo_da_Vinci_-_Mona_Lisa_%28Louvre%2C_Paris%29.jpg/245px-Leonardo_da_Vinci_-_Mona_Lisa_%28Louvre%2C_Paris%29.jpg" heigth= "500px" widht="600px">
    </div>

<hr>
<div>
    <div id="titulocena" onmouseover="teal();"onmouseout="white();">
      <h1>LA ULTIMA CENA</h1>
    </div>
    <div >
      <p><strong>La ultima cena:</strong> Esta pintura de da Vinci es la representación de la última cena, narrada en el Evangelio de San Juan.</p>
    </div>
    <div >
      <p>Es una obra clave del Renacimiento y todo un tratado de perspectiva. La última Cena está pintada al óleo sobre yeso, una técnica no utilizada antes en la pintura mural, por lo que su restauración ha sido un proceso complicado. Hoy en día se encuentra en La Iglesia de Santa Maria delle Grazie.</p>
    </div>
    <div class="imagen_ultima">
      <img src="https://s3.amazonaws.com/rtvc-assets-canalinstitucional.tv/s3fs-public/images/ultima.jpg" heigth= "200px" widht="500px">
  </div>
</div>

  <hr>
  <div>
      <div id="tituloguernica"onmouseover="teal();"onmouseout="white();">
        <h1>LA GUERNICA</h1>
      </div>
      <div >
        <p><strong>Guernica:</strong>Guernica es probablemente una de las obras más trascendentes del pintor Pablo Picasso e igual una de las más impactantes por el tema que toca. A través de esta creación, Picasso ilustra la tragedia del bombardeo a la ciudad de Guernica durante la Guerra Civil Española, por lo que se ha convertido en uno de los símbolos más destacados en contra de la guerra.<p>
      </div>
      <div >
        <p>Actualmente se exhibe en el Museo Nacional Centro de Arte Reina Sofía en Madrid, España.</p>
      </div>
      <div class="imagen_guernica">
        <img src="https://estaticos.muyhistoria.es/media/cache/400x300_thumb/uploads/images/gallery/58eb8c1c5cafe807e58b4588/guernica8_0.jpg" heigth= "200px" widht="500px">
      </div>
  </div>

  <hr>
  <div>
      <div id="titulogrito" onmouseover="teal();"onmouseout="white();">
        <h1>EL GRITO</h1>
      </div>
      <div >
        <p><strong>El grito :</strong>Esta obra del artista holandés Edvard Munch es un ejemplo de la pintura expresionista, donde el paisaje se une al sentimiento del protagonista.
      </div>
      <div >
        <p>Con un rostro deformado el entorno parece hacer eco de su expresión, que contrasta con un fondo naranja, donde dos figuras parecen alejarse sin percatarse del torbellino emocional que expresa la obra. Tiene varias versiones, la primera, expuesta en 1893, se encuentra en la Galería Nacional de Oslo<p></p>
      </div>
      <div class="imagen_grito">
        <img src="http://marisolroman.files.wordpress.com/2012/11/475px-the_scream1.jpg?resize=475%2C599" heigth= "100px" widht="300px">
     </div>
  </div>
</div>

<hr>
<?php
mysqli_free_result($resultado);
mysqli_free_result($resultado2);
mysqli_close($conexion);
 ?>

<footer>
  <p>Crhisttian Moreno_Pagina del arte copyright@</p>
</footer>

</body>
</html>
