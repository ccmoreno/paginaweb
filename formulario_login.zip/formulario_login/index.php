<!DOCTYPE html>
<html>
  <head>
    <link  href="estilofinal.css" rel ="stylesheet" type="text/css">
    <meta charset="utf-8">
    <title>Avance Proyecto Final </title>
  </head>
  <body >

    <form id="formulario" action="validar.php" method="post">
      <div>
        <label>Usuario</label>
        <input type="text" name="usuario" value="">
      </div>
      <div>
        <label>Password</label>
        <input type="password" name="password" value="">
      </div>
      <div id="botones">
        <input type="submit" name="" value="ingresar">
        <input type="reset" name="" value="reset">
      </div>
    </form>

  </body>
</html>
