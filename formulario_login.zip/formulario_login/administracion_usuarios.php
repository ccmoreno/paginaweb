<?php
session_start();
error_reporting(0);
$varsesion = $_SESSION['usuario'];
  if($varsesion == null || $varsesion = '')
  {
    echo "Usted no tiene acceso";
    die();
  }
 ?>
 <!DOCTYPE html>
 <html>
   <head>
     <link  href="estilo_adminusers.css" rel ="stylesheet" type="text/css">
     <meta charset="utf-8">
     <style>
    body
    {
      background-color: #252850;
    }
  </style>
     <title>Adminsitracion de usuarios</title>
   </head>
   <body >
     <h1>Este es el panel de administracion de usuarios </h1>
    <div id="estilos">
        <?php
        $conexion = mysqli_connect("localhost","root","","usuarios");
        if ($conexion -> connect_errno) {
          die("Fallo la conexion: (".$conexion -> mysqli_connect_errno().")".$conexion-> mysqli_connect_errno());
        }
        $sentencia="SELECT * FROM users ";
        $resultadosent=$conexion->query($sentencia);
        echo "<td><a href='agregar_user.php'> <button type='button' class='btn btn-danger'> Agregar Usuario </button></a></td>";
          echo "<table border='2';cellspacing='6 '; cellpadding='6';  class ='table table-hover';>";
          echo "<tr>";
           echo "<td>Id</td>";
           echo "<td>Usuario</td>";
           echo "<td>Password</td>";
           echo "<td>Passadmin</td>";
           echo "<td>Editar</td>";
           echo "<td>Borrar</td>";
           echo "</tr>";
           while ($registro_usuarios = $resultadosent->fetch_array(MYSQLI_BOTH))
          {
             echo"<tr>";
                echo"<td>"; echo$registro_usuarios['id'];echo"</td>";
                echo"<td>"; echo$registro_usuarios['usuario'];echo"</td>";
                echo"<td>"; echo$registro_usuarios['password'];echo"</td>";
                echo"<td>"; echo$registro_usuarios['passadmin'];echo"</td>";
                echo "<td> <a href='editar_user.php?id=".$registro_usuarios['id']."'> <button type='button' class='btn btn-success'>Editar Usuario</button></a></td>";
                echo "<td><a href='modif_eliminar.php?id=".$registro_usuarios['id']."'> <button type='button' class='btn btn-danger'> Eliminar Usuario </button></a></td>";

             echo"</tr>";
          }
 ?>
    </div>
    <h3><a href="cerrar_session.php"style='color: black'>Cerrar sesión</a></h3>
    <h3><a href="panel_admin.php"style='color: black'>Atras</a></h3>
   </body>
 </html>
