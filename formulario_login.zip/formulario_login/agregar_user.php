<?php
session_start();
error_reporting(0);
$varsesion = $_SESSION['usuario'];
  if($varsesion == null || $varsesion = '')
  {
    echo "Usted no tiene acceso";
    die();
  }
 ?>
 <!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>Agregar Usuario</title>
    <link  href="style_agregar.css" rel ="stylesheet" type="text/css">
  </head>
  <style>
 body
 {
   background-color: #252850;
 }
</style>
  <body>
    <form action="modif_agregar.php" method="POST" id="formulario">
      <input type="hidden" name="id">
      <div>
        <label>Usuario</label>
        <input type="text" id="usuario" name="usuario">
      </div>
      <div>
        <label>Password</label>
        <input type="password" id="password" name="password">
      </div>
      <label>Passadmin</label>
      <input type="password" id="passadmin" name="passadmin">
      <br>
      <button type="submit" class="btn btn-success " name="button" >Guardar Cambios</button>
    </form>
  </body>
</html>
